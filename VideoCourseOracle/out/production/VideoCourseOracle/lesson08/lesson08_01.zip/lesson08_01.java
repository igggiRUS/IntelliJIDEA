/*
package lesson08;

public class lesson08_01 {
  // переменная стала константой и она не изменится
  public final int a = 10;

  public static void main(String[] args) {
    lesson08_01 t = new lesson08_01();
    t.a = t.a*2;
    System.out.println(t.a);
  }


}
*/
